---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

## Background

**What is your motivation?**

**What type of application is this?** (E.g. cryptography, game, numerical simulation)

## Feature request

<details here>
